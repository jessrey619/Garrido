import { useNavigate } from "react-router-dom"


export const Header = () => {
    const nav = useNavigate()

    const handleViewInventory = () => {
        nav("/view-inventory")
    }

    const handleAddToInventory = () => {
        nav("/add-to-inventory")
    }

    const handleUpdateStock = () => {
        nav("/update-stock")
    }

    return(
        <div>
            <button onClick={handleViewInventory}>View Inventory</button>
            <button onClick={handleAddToInventory}>Add To Inventory</button>
            <button onClick={handleUpdateStock}>Update Stock</button>
        </div>
    )
}