import axios from "axios";
import { useEffect, useState } from "react";

export const AddToInventory = () => {
    const [options, setOptions] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState();
    const [itemName, setItemName] = useState('');
    const [price, setPrice] = useState('');
    const [quantity, setQuantity] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://127.0.0.1:5000/tableCategories');
                setOptions(response.data);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    const handleCategoryChange = (event) => {
        const selectedCategoryId = event.target.value;
        setSelectedCategory(selectedCategoryId);
    };

    const handleItemNameChange = (event) => {
        setItemName(event.target.value);
    };

    const handlePriceChange = (event) => {
        setPrice(event.target.value);
    };

    const handleQuantityChange = (event) => {
        setQuantity(event.target.value);
    };

    const handleSubmit = async () => {
        try {
            const response = await axios.post('http://127.0.0.1:5000/products', {
                p_product_name: itemName,
                p_price: parseFloat(price),
                p_quantity: parseInt(quantity),
                p_category_id: parseInt(selectedCategory),
            });

            console.log('Product added successfully:', response.data);
            // Optionally, you can reset the form fields after successful submission
            setItemName('');
            setPrice('');
            setQuantity('');
            setSelectedCategory('');
        } catch (error) {
            console.error('Error adding product:', error);
        }
    };

    return (
        <div>
            <input
                id="itemName"
                placeholder="Item Name"
                value={itemName}
                onChange={handleItemNameChange}
            /><br />
            <select
                onChange={handleCategoryChange}
                value={selectedCategory}
                placeholder="Category"
            >
                <option value="">Select a category</option>
                {options.map((option) => (
                    <option key={option.category_id} value={option.category_id}>
                        {option.category_name}
                    </option>
                ))}
            </select><br />
            <input
                id="price"
                placeholder="Price"
                value={price}
                onChange={handlePriceChange}
            /><br />
            <input
                id="quantity"
                placeholder="Quantity"
                type="number"
                value={quantity}
                onChange={handleQuantityChange}
            /><br/>
            <button onClick={handleSubmit}>Submit</button>
        </div>
    );
};
